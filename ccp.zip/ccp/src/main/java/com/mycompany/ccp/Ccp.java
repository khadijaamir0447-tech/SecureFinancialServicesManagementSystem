/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ccp;
import java.sql.*;
import Database.*;
import module1.*;
import module2.*;
import module3.*;
import module4.*;
import module5.*;
import module6.*;
import java.math.BigDecimal;
import java.util.*;
/**
 *
 * @author al karam
 */

public class Ccp {

    public static void main(String[] args) {
        Connection connection =
        DBConnection.getConnection();

if(connection != null) {
    System.out.println("Database Connected");
}
else {
    System.out.println("Connection Failed");
}
        try (Scanner input = new Scanner(System.in)) {
            AuthenticationService authService =
                    new AuthenticationService();
            
            AccountService accountService =
                    new AccountService();
            
            TransactionService transactionService =
                    new TransactionService();
            
            LoanService loanService =
                    new LoanService();
            
            ReportService reportService =
                    new ReportService();
            
            ArrayList<Transaction> transactions =
                    transactionService.getTransactions();
            
            User currentUser = null;
            Account currentAccount = null;
            
            int choice;
            
            do {
                
                System.out.println("====================================");
                System.out.println(" SECURE FINANCIAL MANAGEMENT SYSTEM ");
                System.out.println("====================================");
                System.out.println("1. Register User");
                System.out.println("2. Login User");
                System.out.println("3. Open Bank Account");
                System.out.println("4. Deposit Money");
                System.out.println("5. Withdraw Money");
                System.out.println("6. Fund Transfer");
                System.out.println("7. Bill Payment");
                System.out.println("8. Balance Inquiry");
                System.out.println("9. Calculate Interest");
                System.out.println("10. Apply Loan");
                System.out.println("11. View Mini Statement");
                System.out.println("12. View Full Statement");
                System.out.println("13. Export Statement");
                System.out.println("14. Security Demo");
                System.out.println("15. Admin Dashboard");
                System.out.println("16. Delete User");
                System.out.println("17. Unlock User");
                System.out.println("0. Exit");
                System.out.print("Enter Choice: ");
                
                choice = input.nextInt();
                input.nextLine();
                
                switch(choice) {
                    
                    case 1 -> {
                        System.out.print("Full Name: ");
                        String name = input.nextLine();
                        
                        System.out.print("Email: ");
                        String email = input.nextLine();
                        
                        System.out.print("Phone: ");
                        String phone = input.nextLine();
                        
                        System.out.print("Date Of Birth: ");
                        String dob = input.nextLine();
                        
                        System.out.print("National ID: ");
                        String nationalId = input.nextLine();
                        
                        System.out.print("Password: ");
                        String password = input.nextLine();
                        
                        authService.registerUser(
                                name,
                                email,
                                phone,
                                dob,
                                nationalId,
                                password,
                                UserRole.CUSTOMER
                        );
                    }
                    
                    case 2 -> {
                        System.out.print("Email: ");
                        String loginEmail = input.nextLine();
                        
                        System.out.print("Password: ");
                        String loginPassword = input.nextLine();
                        
                        currentUser = authService.login(
                                loginEmail,
                                loginPassword
                        );
                    }
                    
                    case 3 -> {
                        if (currentUser == null) {
                            System.out.println("Please Login First");
                            break;
                        }
                        
                        System.out.println("1. SAVINGS");
                        System.out.println("2. CURRENT");
                        System.out.println("3. FIXED_DEPOSIT");
                        
                        int typeChoice = input.nextInt();
                        
                        AccountType type;
                        
                        type = switch (typeChoice) {
                            case 1 -> AccountType.SAVINGS;
                            case 2 -> AccountType.CURRENT;
                            default -> AccountType.FIXED_DEPOSIT;
                        };
                        
                        currentAccount = accountService.openAccount(
                                currentUser.getFullName(),
                                type
                        );
                    }
                    
                    case 4 -> {
                        if (currentAccount == null) {
                            System.out.println("Open Account First");
                            break;
                        }
                        
                        System.out.print("Enter Deposit Amount: ");
                        BigDecimal deposit = input.nextBigDecimal();
                        
                        transactionService.cashDeposit(
                                currentAccount,
                                deposit
                        );
                    }
                    
                    case 5 -> {
                        if (currentAccount == null) {
                            System.out.println("Open Account First");
                            break;
                        }
                        
                        try {
                            
                            System.out.print("Enter Withdrawal Amount: ");
                            BigDecimal withdraw = input.nextBigDecimal();
                            
                            transactionService.cashWithdrawal(
                                    currentAccount,
                                    withdraw
                            );
                            
                        } catch (LimitExceededException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    
                    case 6 -> {
                        if (currentAccount == null) {
                            System.out.println("Open Account First");
                            break;
                        }
                        
                        Account receiver = accountService.openAccount(
                                "Receiver User",
                                AccountType.CURRENT
                        );
                        
                        System.out.print("Enter Transfer Amount: ");
                        BigDecimal transfer = input.nextBigDecimal();
                        
                        transactionService.fundTransfer(
                                currentAccount,
                                receiver,
                                transfer
                        );
                    }
                    
                    case 7 -> {
                        if (currentAccount == null) {
                            System.out.println("Open Account First");
                            break;
                        }
                        
                        input.nextLine();
                        
                        System.out.print("Bill Type: ");
                        String billType = input.nextLine();
                        
                        System.out.print("Bill Amount: ");
                        BigDecimal billAmount = input.nextBigDecimal();
                        
                        transactionService.billPayment(
                                currentAccount,
                                billAmount,
                                billType
                        );
                    }
                    
                    case 8 -> {
                        if (currentAccount == null) {
                            System.out.println("Open Account First");
                            break;
                        }
                        
                        accountService.checkBalance(currentAccount);
                    }
                    
                    case 9 -> {
                        if (currentAccount == null) {
                            System.out.println("Open Account First");
                            break;
                        }
                        
                        System.out.print("Enter Annual Interest Rate: ");
                        double rate = input.nextDouble();
                        
                        accountService.calculateMonthlyInterest(
                                currentAccount,
                                rate
                        );
                    }
                    
                    case 10 -> {
                        if (currentUser == null) {
                            System.out.println("Please Login First");
                            break;
                        }
                        
                        System.out.print("Loan Amount: ");
                        double principal = input.nextDouble();
                        
                        System.out.print("Annual Interest Rate: ");
                        double annualRate = input.nextDouble();
                        
                        System.out.print("Loan Duration (Months): ");
                        int months = input.nextInt();
                        
                        System.out.print("Credit Score: ");
                        int creditScore = input.nextInt();
                        
                        Loan loan = loanService.applyLoan(
                                currentUser.getFullName(),
                                principal,
                                annualRate,
                                months,
                                creditScore
                        );
                        
                        double emi = loanService.calculateEMI(
                                principal,
                                annualRate,
                                months
                        );
                        
                        System.out.println("Monthly EMI: " + emi);
                        
                        loanService.repaymentSchedule(loan);
                    }
                    
                    case 11 -> reportService.miniStatement(transactions);
                    
                    case 12 -> reportService.fullStatement(transactions);
                    
                    case 13 -> reportService.exportStatement(
                            transactions,
                            "statement.txt"
                    );
                    
                    case 14 -> {
                        try {
                            
                            String encrypted =
                                    SecurityUtil.encrypt("Secure Banking");
                            
                            System.out.println(
                                    "Encrypted Data: " + encrypted
                            );
                            
                            String decrypted =
                                    SecurityUtil.decrypt(encrypted);
                            
                            System.out.println(
                                    "Decrypted Data: " + decrypted
                            );
                            
                            if (currentAccount != null) {
                                
                                System.out.println(
                                        "Masked Account Number: " +
                                                SecurityUtil.maskAccountNumber(
                                                        currentAccount.getAccountNumber()
                                                )
                                );
                            }
                            
                        } catch (Exception e) {
                        }
                    }
                    
                    case 15 -> reportService.adminDashboard(
                            accountService.getAccounts(),
                            500000,
                            100000,
                            2
                    );
                    case 16 -> {

    System.out.print("Enter User Email To Delete: ");

    String deleteEmail =
            input.nextLine();

    authService.deleteUser(deleteEmail);
}
                    case 17 -> {

    System.out.print("Enter User Email To Unlock: ");

    String unlockEmail =
            input.nextLine();

    authService.unlockUser(unlockEmail);
}
                    
                    case 0 -> System.out.println("Thank You For Using Our Banking System");
                    
                    default -> System.out.println("Invalid Choice");
                }
                
            } while (choice != 0);
        }
    }
}


