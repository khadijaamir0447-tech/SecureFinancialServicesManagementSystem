/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module6;
import java.sql.*;
import Database.*;
import module2.*;
import module3.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
/**
 *
 * @author al karam
 */
public class ReportService {
    public void miniStatement(ArrayList<Transaction> transactions) {
try {

    try (Connection connection = DBConnection.getConnection()) {
        String query =
                "SELECT TOP 5 * FROM transactions ORDER BY id DESC";
        
        PreparedStatement ps =
                connection.prepareStatement(query);
        
        ResultSet rs =
                ps.executeQuery();
        
        System.out.println(
                "===== MINI STATEMENT ====="
        );
        
        while(rs.next()) {
            
            System.out.println(
                    rs.getString("transaction_id")
            );
            
            System.out.println(
                    rs.getString("transaction_type")
            );
            
            System.out.println(
                    rs.getDouble("amount")
            );
            
            System.out.println(
                    "-------------------"
            );
        }
    }

} catch (SQLException e) {
}
        }
    

    public void fullStatement(ArrayList<Transaction> transactions) {

        try {

            try (Connection connection = DBConnection.getConnection()) {
                String query =
                        "SELECT * FROM transactions";
                
                PreparedStatement ps =
                        connection.prepareStatement(query);
                
                ResultSet rs =
                        ps.executeQuery();
                
                System.out.println(
                        "===== FULL STATEMENT ====="
                );
                
                while(rs.next()) {
                    
                    System.out.println(
                            rs.getString("transaction_id")
                    );
                    
                    System.out.println(
                            rs.getString("transaction_type")
                    );
                    
                    System.out.println(
                            rs.getDouble("amount")
                    );
                    
                    System.out.println(
                            rs.getTimestamp("transaction_time")
                    );
                    
                    System.out.println(
                            "----------------------"
                    );
                }       }

} catch (SQLException e) {
}
        }

    public void exportStatement(ArrayList<Transaction> transactions,
                                String fileName) {

        try {

            try (FileWriter writer = new FileWriter(fileName)) {
                for (Transaction transaction : transactions) {
                    writer.write(transaction.toString() + "\n");
                }
            }

            System.out.println("Statement Exported Successfully");

        } catch (IOException e) {
        }
    }

    public void adminDashboard(ArrayList<Account> accounts,
                               double totalDeposits,
                               double outstandingLoans,
                               int flaggedTransactions) {

        System.out.println("===== ADMIN DASHBOARD =====");
        System.out.println("Total Accounts: " + accounts.size());
        System.out.println("Total Deposits: " + totalDeposits);
        System.out.println("Outstanding Loans: " + outstandingLoans);
        System.out.println("Flagged Transactions: " + flaggedTransactions);
    }
}
