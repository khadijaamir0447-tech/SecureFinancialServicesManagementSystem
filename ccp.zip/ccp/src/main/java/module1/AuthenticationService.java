/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module1;
import java.sql.*;
import Database.*;
import java.util.*;
import module5.*;
/**
 *
 * @author al karam
 */
public class AuthenticationService {
     private ArrayList<User> users = new ArrayList<>();

    public void registerUser(String fullName,
                             String email,
                             String phone,
                             String dob,
                             String nationalId,
                             String password,
                             UserRole role) {

        if (!ValidationUtil.validateEmail(email)) {
            System.out.println("Invalid Email");
            return;
        }

        if (!ValidationUtil.validatePhone(phone)) {
            System.out.println("Invalid Phone Number");
            return;
        }

        if (!ValidationUtil.validatePassword(password)) {
            System.out.println("Weak Password");
            return;
        }

        String hashedPassword = SecurityUtil.hashPassword(password);

        User user = new User(fullName, email, phone,
                dob, nationalId,
                hashedPassword, role);

        users.add(user);
        try {

            try (Connection connection = DBConnection.getConnection()) {
                String query =
                        "INSERT INTO users(Full_Name,Email,Phone,DOB,National_ID,Password,Role) VALUES(?,?,?,?,?,?,?)";
                
                PreparedStatement ps =
                        connection.prepareStatement(query);
                
                ps.setString(1, fullName);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, dob);
                ps.setString(5, nationalId);
                ps.setString(6, hashedPassword);
                ps.setString(7, role.toString());
                
                ps.executeUpdate();
                
                System.out.println(
                        "User Saved In Database"
                );      }

} catch (SQLException e) {
}

        System.out.println("User Registered Successfully");
    }

    public User login(String email, String password) {

       String hashedPassword =
            SecurityUtil.hashPassword(password);

    try (Connection connection =
                 DBConnection.getConnection()) {

        String query =
                "SELECT * FROM users WHERE Email=?";

        PreparedStatement ps =
                connection.prepareStatement(query);

        ps.setString(1, email);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {

            boolean locked =
                    rs.getBoolean("locked");

            int attempts =
                    rs.getInt("failed_attempts");

            if (locked) {

                System.out.println(
                        "Account Locked Due To 3 Failed Attempts"
                );

                return null;
            }

            String dbPassword =
                    rs.getString("Password");

            if (dbPassword.equals(hashedPassword)) {

                String resetQuery =
                        "UPDATE users SET failed_attempts=0 WHERE Email=?";

                PreparedStatement resetPs =
                        connection.prepareStatement(resetQuery);

                resetPs.setString(1, email);

                resetPs.executeUpdate();

                User user = new User(
                        rs.getString("Full_Name"),
                        rs.getString("Email"),
                        rs.getString("Phone"),
                        rs.getString("DOB"),
                        rs.getString("National_ID"),
                        rs.getString("Password"),
                        UserRole.valueOf(
                                rs.getString("Role")
                        )
                );

                System.out.println(
                        "Login Successful"
                );

                return user;
            }

            else {

                attempts++;

                System.out.println(
                        "Incorrect Password"
                );

                System.out.println(
                        "Attempts Used: "
                                + attempts + "/3"
                );

                if (attempts >= 3) {

                    String lockQuery =
                            "UPDATE users SET failed_attempts=?, locked=true WHERE Email=?";

                    PreparedStatement lockPs =
                            connection.prepareStatement(lockQuery);

                    lockPs.setInt(1, attempts);
                    lockPs.setString(2, email);

                    lockPs.executeUpdate();

                    System.out.println(
                            "Account Locked After 3 Failed Attempts"
                    );
                }

                else {

                    String updateQuery =
                            "UPDATE users SET failed_attempts=? WHERE Email=?";

                    PreparedStatement updatePs =
                            connection.prepareStatement(updateQuery);

                    updatePs.setInt(1, attempts);
                    updatePs.setString(2, email);

                    updatePs.executeUpdate();
                }

                return null;
            }
        }

        else {

            System.out.println(
                    "User Not Found"
            );

            return null;
        }

    }

    catch (SQLException e) {
    }

    return null;
    }
    public void unlockUser(String email) {

    try (Connection connection =
                 DBConnection.getConnection()) {

        String query =
                "UPDATE users SET failed_attempts=0, locked=false WHERE Email=?";

        PreparedStatement ps =
                connection.prepareStatement(query);

        ps.setString(1, email);

        int rows =
                ps.executeUpdate();

        if(rows > 0) {

            System.out.println(
                    "User Unlocked Successfully"
            );
        }

        else {

            System.out.println(
                    "User Not Found"
            );
        }

    }

    catch (SQLException e) {
    }
}
public void deleteUser(String email) {

    try (Connection connection =
                 DBConnection.getConnection()) {

        String query =
                "DELETE FROM users WHERE Email=?";

        PreparedStatement ps =
                connection.prepareStatement(query);

        ps.setString(1, email);

        int rows =
                ps.executeUpdate();

        if(rows > 0) {

            System.out.println(
                    "User Deleted Successfully"
            );
        }

        else {

            System.out.println(
                    "User Not Found"
            );
        }

    }

    catch (SQLException e) {
    }
}
    public void resetPassword(String email, String newPassword) {

        for (User user : users) {

            if (user.getEmail().equals(email)) {

                user.setPassword(SecurityUtil.hashPassword(newPassword));
                user.resetAttempts();

                user.setLocked(false);

                System.out.println("Password Reset Successful");
                return;
            }
        }

        System.out.println("User Not Found");
    }

    public ArrayList<User> getUsers() {
        return users;
    }

}
