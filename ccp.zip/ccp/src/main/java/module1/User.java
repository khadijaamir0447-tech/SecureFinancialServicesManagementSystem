/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module1;

/**
 *
 * @author al karam
 */
public class User {
    private String fullName;
    private String email;
    private String phone;
    private String dob;
    private String nationalId;
    private String password;
    private UserRole role;
    private int failedAttempts=0;
    private boolean locked=false;

    public User(String fullName, String email, String phone,
                String dob, String nationalId,
                String password, UserRole role) {

        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.dob = dob;
        this.nationalId = nationalId;
        this.password = password;
        this.role = role;
        this.failedAttempts = 0;
        this.locked = false;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getDob() {
        return dob;
    }

    public String getNationalId() {
        return nationalId;
    }

    public String getPassword() {
        return password;
    }

    public UserRole getRole() {
        return role;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public boolean isLocked() {
        return locked;
    }

    public void incrementFailedAttempts() {
        failedAttempts++;
    }

    public void resetAttempts() {
        failedAttempts = 0;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public void setLocked(boolean locked) {
    this.locked = locked;
}

}
