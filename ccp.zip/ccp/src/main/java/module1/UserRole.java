/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module1;

/**
 *
 * @author al karam
 */
public enum UserRole {
    CUSTOMER,
    TELLER,
    ADMIN
}
