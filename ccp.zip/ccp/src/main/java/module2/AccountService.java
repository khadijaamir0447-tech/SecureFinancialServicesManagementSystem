/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module2;
import java.sql.*;
import Database.*;
import java.util.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
/**
 *
 * @author al karam
 */
public class AccountService {
    private ArrayList<Account> accounts = new ArrayList<>();

    public Account openAccount(String ownerName,
                               AccountType type) {

        String accountNumber = generateAccountNumber();

        Account account = new Account(accountNumber,
                ownerName,
                type);

        accounts.add(account);
        try {

            try (Connection connection = DBConnection.getConnection()) {
                String query =
                        "INSERT INTO accounts(Account_No,Owner_Name,Account_Type,Account_Status,Balance) VALUES(?,?,?,?,?)";
                
                PreparedStatement ps =
                        connection.prepareStatement(query);
                
                ps.setString(1, accountNumber);
                ps.setString(2, ownerName);
                ps.setString(3, type.toString());
                ps.setString(4, "ACTIVE");
                ps.setBigDecimal(5, BigDecimal.ZERO);
                
                ps.executeUpdate();
                
                System.out.println(
                        "Account Saved In Database"
                );      }

} catch (SQLException e) {
}

        System.out.println("Account Opened Successfully");
        System.out.println("Account Number: " + accountNumber);

        return account;
    }

    private String generateAccountNumber() {

        Random random = new Random();
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            sb.append(random.nextInt(10));
        }

        return sb.toString();
    }

    public void deposit(Account account,
                        BigDecimal amount) {

        account.deposit(amount);

        System.out.println("Deposit Successful");
    }

    public void withdraw(Account account,
                         BigDecimal amount) {

        if (account.getBalance().compareTo(amount) >= 0) {

            account.withdraw(amount);
            System.out.println("Withdrawal Successful");
        }

        else {
            System.out.println("Insufficient Balance");
        }
    }

    public void checkBalance(Account account) {
        System.out.println("Current Balance: " + account.getBalance());
    }

    public void closeAccount(Account account) {

        if (account.getBalance().compareTo(BigDecimal.ZERO) == 0) {

            account.setStatus(AccountStatus.CLOSED);
            System.out.println("Account Closed");
        }

        else {
            System.out.println("Balance Must Be Zero First");
        }
    }

    public void calculateMonthlyInterest(Account account,
                                         double annualRate) {

        BigDecimal monthlyRate = BigDecimal.valueOf(annualRate)
                .divide(BigDecimal.valueOf(12 * 100),
                        5,
                        RoundingMode.HALF_UP);

        BigDecimal interest = account.getBalance()
                .multiply(monthlyRate);

        account.deposit(interest);

        System.out.println("Interest Added: " + interest);
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }

}
