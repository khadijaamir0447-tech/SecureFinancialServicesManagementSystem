/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module2;

/**
 *
 * @author al karam
 */
public enum AccountStatus {
     ACTIVE,
    SUSPENDED,
    CLOSED
}
