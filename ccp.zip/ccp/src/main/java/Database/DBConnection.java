/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;
import java.sql.*;
/**
 *
 * @author al karam
 */
public class DBConnection {
    public static Connection getConnection() {

        try {

            String url =
                "jdbc:ucanaccess://C:/Users/al karam/Documents/banking_system.accdb";

            Connection connection =
                    DriverManager.getConnection(url);

            return connection;

        } catch (SQLException e) {
        }

        return null;
    }
}
