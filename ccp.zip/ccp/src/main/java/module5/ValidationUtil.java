/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module5;

/**
 *
 * @author al karam
 */
public class ValidationUtil {
    public static boolean validateEmail(String email) {
        return email.contains("@") && email.contains(".");
    }

    public static boolean validatePhone(String phone) {
        return phone.matches("\\d{11}");
    }

    public static boolean validatePassword(String password) {
        return password.length() >= 8;
    }

    public static boolean validateNationalId(String id) {
        return id.matches("\\d{13}");
    }
}
