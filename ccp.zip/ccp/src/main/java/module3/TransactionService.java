/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module3;
import java.sql.*;
import Database.*;
import module2.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/**
 *
 * @author al karam
 */
public class TransactionService {
  private ArrayList<Transaction> transactions = new ArrayList<>();

    private static final double DAILY_LIMIT = 50000;
    private double dailyWithdrawn = 0;

    public void cashDeposit(Account account,
                            BigDecimal amount) {

        account.deposit(amount);

        Transaction transaction = new Transaction(
                generateTransactionId(),
                "Cash Deposit",
                amount.doubleValue()
        );

        transactions.add(transaction);
        try {

            try (Connection connection = DBConnection.getConnection()) {
                String query =
                        "INSERT INTO transactions(Transaction_ID,Transaction_Type,Amount) VALUES(?,?,?)";
                
                PreparedStatement ps =
                        connection.prepareStatement(query);
                
                ps.setString(1,
                        transaction.getTransactionId());
                
                ps.setString(2,
                        transaction.getType());
                
                ps.setDouble(3,
                        transaction.getAmount());
                
                ps.executeUpdate();
                
                System.out.println(
                        "Transaction Saved In Database"
                );      }

} catch (SQLException e) {
}

        System.out.println("Deposit Successful");
        generateReceipt(transaction);
    }

    public void cashWithdrawal(Account account,
                               BigDecimal amount)
            throws LimitExceededException {

        if (dailyWithdrawn + amount.doubleValue() > DAILY_LIMIT) {

            throw new LimitExceededException(
                    "Daily Withdrawal Limit Exceeded"
            );
        }

        if (account.getBalance().compareTo(amount) >= 0) {

            account.withdraw(amount);
            dailyWithdrawn += amount.doubleValue();

            Transaction transaction = new Transaction(
                    generateTransactionId(),
                    "Cash Withdrawal",
                    amount.doubleValue()
            );

            transactions.add(transaction);
            try {

                try (Connection connection = DBConnection.getConnection()) {
                    String query =
                            "INSERT INTO transactions(transaction_id,transaction_type,amount) VALUES(?,?,?)";
                    
                    PreparedStatement ps =
                            connection.prepareStatement(query);
                    
                    ps.setString(1,
                            transaction.getTransactionId());
                    
                    ps.setString(2,
                            transaction.getType());
                    
                    ps.setDouble(3,
                            transaction.getAmount());
                    
                    ps.executeUpdate();
                    
                    System.out.println(
                            "Transaction Saved In Database"
                    );          }

} catch (SQLException e) {
}

            System.out.println("Withdrawal Successful");
            generateReceipt(transaction);
        }

        else {
            System.out.println("Insufficient Balance");
        }
    }

    public void fundTransfer(Account sender,
                             Account receiver,
                             BigDecimal amount) {

        if (sender.getBalance().compareTo(amount) >= 0) {

            sender.withdraw(amount);
            receiver.deposit(amount);

            Transaction transaction = new Transaction(
                    generateTransactionId(),
                    "Fund Transfer",
                    amount.doubleValue()
            );

            transactions.add(transaction);
            try {

                try (Connection connection = DBConnection.getConnection()) {
                    String query =
                            "INSERT INTO transactions(transaction_id,transaction_type,amount) VALUES(?,?,?)";
                    
                    PreparedStatement ps =
                            connection.prepareStatement(query);
                    
                    ps.setString(1,
                            transaction.getTransactionId());
                    
                    ps.setString(2,
                            transaction.getType());
                    
                    ps.setDouble(3,
                            transaction.getAmount());
                    
                    ps.executeUpdate();
                    
                    System.out.println(
                            "Transaction Saved In Database"
                    );          }

} catch (SQLException e) {
}

            System.out.println("Transfer Successful");
            generateReceipt(transaction);
        }

        else {
            System.out.println("Insufficient Balance");
        }
    }

    public void billPayment(Account account,
                            BigDecimal amount,
                            String billType) {

        if (account.getBalance().compareTo(amount) >= 0) {

            account.withdraw(amount);

            Transaction transaction = new Transaction(
                    generateTransactionId(),
                    billType + " Bill Payment",
                    amount.doubleValue()
            );

            transactions.add(transaction);
            try {

                try (Connection connection = DBConnection.getConnection()) {
                    String query =
                            "INSERT INTO transactions(transaction_id,transaction_type,amount) VALUES(?,?,?)";
                    
                    PreparedStatement ps =
                            connection.prepareStatement(query);
                    
                    ps.setString(1,
                            transaction.getTransactionId());
                    
                    ps.setString(2,
                            transaction.getType());
                    
                    ps.setDouble(3,
                            transaction.getAmount());
                    
                    ps.executeUpdate();
                    
                    System.out.println(
                            "Transaction Saved In Database"
                    );          }

} catch (SQLException e) {
}

            System.out.println("Bill Payment Successful");
            generateReceipt(transaction);
        }

        else {
            System.out.println("Insufficient Balance");
        }
    }

    public void transactionHistory() {

        System.out.println("===== TRANSACTION HISTORY =====");

        try {

            try (Connection connection = DBConnection.getConnection()) {
                String query =
                        "SELECT * FROM transactions";
                
                PreparedStatement ps =
                        connection.prepareStatement(query);
                
                ResultSet rs =
                        ps.executeQuery();
                
                System.out.println(
                        "===== TRANSACTION HISTORY ====="
                );
                
                while(rs.next()) {
                    
                    System.out.println(
                            rs.getString("transaction_id")
                    );
                    
                    System.out.println(
                            rs.getString("transaction_type")
                    );
                    
                    System.out.println(
                            rs.getDouble("amount")
                    );
                    
                    System.out.println(
                            rs.getTimestamp("transaction_time")
                    );
                    
                    System.out.println(
                            "-----------------------"
                    );
                }   }

    } catch (SQLException e) {
    }
        }
    


    public void searchTransaction(String transactionId) {

        for (Transaction transaction : transactions) {

            if (transaction.getTransactionId().equals(transactionId)) {
                System.out.println(transaction);
                return;
            }
        }

        System.out.println("Transaction Not Found");
    }

    private String generateTransactionId() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    public void generateReceipt(Transaction transaction) {

        System.out.println("===== TRANSACTION RECEIPT =====");
        System.out.println("Transaction ID: " +
                transaction.getTransactionId());
        System.out.println("Type: " + transaction.getType());
        System.out.println("Amount: " + transaction.getAmount());
        System.out.println("Timestamp: " +
                LocalDateTime.now());
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }
}
