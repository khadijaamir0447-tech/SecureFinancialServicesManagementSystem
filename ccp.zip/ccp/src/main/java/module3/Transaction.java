/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module3;
import java.time.LocalDateTime;

/**
 *
 * @author al karam
 */
public class Transaction {
   
    private String transactionId;
    private String type;
    private double amount;
    private LocalDateTime timestamp;

    public Transaction(String transactionId,
                       String type,
                       double amount) {

        this.transactionId = transactionId;
        this.type = type;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return transactionId + " | " + type + " | " + amount + " | " + timestamp;
    }
}
