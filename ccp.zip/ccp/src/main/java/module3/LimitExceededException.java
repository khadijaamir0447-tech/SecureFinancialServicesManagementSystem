/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module3;

/**
 *
 * @author al karam
 */
public class LimitExceededException extends Exception{
    public LimitExceededException(String message) {
        super(message);
    }
}
