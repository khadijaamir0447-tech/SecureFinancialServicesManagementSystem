/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module4;
/**
 *
 * @author al karam
 */
public class Loan {
      private String applicantName;
    private double principal;
    private double annualRate;
    private int months;
    private int creditScore;
    private LoanStatus status;

    public Loan(String applicantName,
                double principal,
                double annualRate,
                int months,
                int creditScore) {

        this.applicantName = applicantName;
        this.principal = principal;
        this.annualRate = annualRate;
        this.months = months;
        this.creditScore = creditScore;
        this.status = LoanStatus.PENDING;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public double getPrincipal() {
        return principal;
    }

    public double getAnnualRate() {
        return annualRate;
    }

    public int getMonths() {
        return months;
    }

    public int getCreditScore() {
        return creditScore;
    }

    public LoanStatus getStatus() {
        return status;
    }

    public void setStatus(LoanStatus status) {
        this.status = status;
    }
}
