/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module4;
import java.sql.*;
import Database.*;
import java.util.*;
/**
 *
 * @author al karam
 */
public class LoanService {
    private ArrayList<Loan> loans = new ArrayList<>();

    public Loan applyLoan(String applicantName,
                          double principal,
                          double annualRate,
                          int months,
                          int creditScore) {

        Loan loan = new Loan(
                applicantName,
                principal,
                annualRate,
                months,
                creditScore
        );

        if (creditScore >= 650) {
            loan.setStatus(LoanStatus.APPROVED);
        }

        else {
            loan.setStatus(LoanStatus.DEFAULTED);
        }

        loans.add(loan);
        try {

            try (Connection connection = DBConnection.getConnection()) {
                String query =
                        "INSERT INTO loans(Applicant_Name,Principal,Annual_Rate,Months,Credit_Score,Loan_Status) VALUES(?,?,?,?,?,?)";
                
                PreparedStatement ps =
                        connection.prepareStatement(query);
                
                ps.setString(1,
                        applicantName);
                
                ps.setDouble(2,
                        principal);
                
                ps.setDouble(3,
                        annualRate);
                
                ps.setInt(4,
                        months);
                
                ps.setInt(5,
                        creditScore);
                
                ps.setString(6,
                        loan.getStatus().toString());
                
                ps.executeUpdate();
                
                System.out.println(
                        "Loan Saved In Database"
                );      }

} catch (SQLException e) {
}

        System.out.println("Loan Application Submitted");
        System.out.println("Loan Status: " + loan.getStatus());

        return loan;
    }
public void viewLoans() {

    try {

        try (Connection connection = DBConnection.getConnection()) {
            String query =
                    "SELECT * FROM loans";
            
            PreparedStatement ps =
                    connection.prepareStatement(query);
            
            ResultSet rs =
                    ps.executeQuery();
            
            System.out.println(
                    "===== LOAN RECORDS ====="
            );
            
            while(rs.next()) {
                
                System.out.println(
                        rs.getString("applicant_name")
                );
                
                System.out.println(
                        rs.getDouble("principal")
                );
                
                System.out.println(
                        rs.getString("loan_status")
                );
                
                System.out.println(
                        "---------------------"
                );
            }
        }

    } catch (SQLException e) {
    }
}
    public double calculateEMI(double principal,
                               double annualRate,
                               int months) {

        double monthlyRate = annualRate / 12 / 100;

        double emi = (principal * monthlyRate *
                Math.pow(1 + monthlyRate, months))
                /
                (Math.pow(1 + monthlyRate, months) - 1);

        return emi;
    }

    public void repaymentSchedule(Loan loan) {

        double emi = calculateEMI(
                loan.getPrincipal(),
                loan.getAnnualRate(),
                loan.getMonths()
        );

        System.out.println("===== REPAYMENT SCHEDULE =====");

        for (int i = 1; i <= loan.getMonths(); i++) {

            System.out.println(
                    "Month " + i +
                            " -> EMI: " + emi
            );
        }
    }

    public void overdueDetection(Loan loan,
                                 int missedPayments) {

        if (missedPayments >= 3) {

            loan.setStatus(LoanStatus.DEFAULTED);

            System.out.println("Loan Marked As DEFAULTED");
        }

        else {
            System.out.println("Loan Payments Normal");
        }
    }

    public void loanStatus(Loan loan) {

        System.out.println("===== LOAN STATUS =====");
        System.out.println("Applicant: " +
                loan.getApplicantName());
        System.out.println("Status: " +
                loan.getStatus());
    }

    public ArrayList<Loan> getLoans() {
        return loans;
    }
}
