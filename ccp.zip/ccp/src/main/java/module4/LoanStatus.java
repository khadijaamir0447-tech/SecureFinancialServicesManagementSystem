/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module4;

/**
 *
 * @author al karam
 */
public enum LoanStatus {
    PENDING, APPROVED, ACTIVE, CLOSED, DEFAULTED
}
